package com.examples.TrainManagement.Model;

public class Bogie {
	private String station;
	private Integer distance;
	
	public Bogie(String station, Integer distance) {
		this.station = station;
		this.distance = distance;
	}
	
	public String getStation() {
		return station;
	}
	public void setStation(String station) {
		this.station = station;
	}

	public Integer getDistance() {
		return distance;
	}
	public void setDistance(Integer distance) {
		this.distance = distance;
	}
	

}
