package com.examples.TrainManagement.Model;


import java.util.List;
import java.util.Map;

public class Train {
	
	private String name; 
	private List<Bogie> trainBogies;
	
	public List<Bogie> getTrainBogies() {
		return trainBogies;
	}


	public void setTrainBogies(List<Bogie> trainBogies) {
		this.trainBogies = trainBogies;
	}


	public Train(String name) {
		this.name = name;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

}
