package com.examples.TrainManagement.Controller;

import java.util.ArrayList;
import java.util.List;
import com.examples.TrainManagement.Constant.Constants;
import com.examples.TrainManagement.Model.Bogie;
import com.examples.TrainManagement.Model.Train;

public class Controller {
	private List<Train> trainDetails = null;
	private List<Train> trainArrivalDetails = null;
	int trainNo = 1;
	
	public void inputData(String path)  {		
    	try {
    		List<String> dataList = Constants.getExternalData(Constants.FILE_PATH);
    		trainDetails = new ArrayList<Train>();
    		for(String data : dataList) {
    			
    			String[] dataArr = data.split(Constants._SPACE);
    			
    			if(Constants.validateInput(dataArr) && trainNo <=2) {    				
    				trainDetails.add(Constants.getTrainObject(dataArr,trainNo));
    				trainNo++;
    			}
    		}
    		trainNo = 1;
    	}catch(Exception e) {
    		System.out.println("An error occurred while inputData");
    		e.printStackTrace();
    	}	
    	
	}
	
	public void processArrivalData() {
		try {
			if(trainDetails != null) {
				trainArrivalDetails = new ArrayList<Train>();
				List<Bogie> bogies = new ArrayList<Bogie>();
				for(Train train : trainDetails) {
					
					Train arrivalTrain = new Train(train.getName());
					arrivalTrain.setTrainBogies(Constants.filteredBogie(train.getTrainBogies(), trainNo));
					trainArrivalDetails.add(arrivalTrain);
					bogies.addAll(arrivalTrain.getTrainBogies());
					trainNo++;
				}
				trainNo = 1;
				Train arrivalMergeTrain = new Train(Constants.TRAIN_AB);
				arrivalMergeTrain.setTrainBogies(Constants.mergedBogie(bogies));	
				trainArrivalDetails.add(arrivalMergeTrain);
			}
		}catch(Exception e) {
			System.out.println("An error occurred while processArrivalData");
    		e.printStackTrace();
		}
	}
	
	public void outputData() {
		if(trainArrivalDetails != null) {
			for(Train train : trainArrivalDetails) {
				if(train.getName().equals(Constants.TRAIN_AB)) {
					System.out.print(Constants.DEPARTURE);
				}else {
					System.out.print(Constants.ARRIVAL);
				}
				
				System.out.print(Constants._SPACE);
				System.out.print(train.getName());
				System.out.print(Constants._SPACE);
				System.out.print(Constants.ENGINE);
				System.out.print(Constants._SPACE);
				if(train.getName().equals(Constants.TRAIN_AB)) {
					System.out.print(Constants.ENGINE);
					System.out.print(Constants._SPACE);
				}
				train.getTrainBogies().forEach(b -> System.out.print(b.getStation()+Constants._SPACE));
				System.out.println(Constants._SPACE);
				System.out.println("====");
			}
		}
	}
	
	public void clearContent() {
		trainDetails = null;
		trainArrivalDetails = null;
	}
}
