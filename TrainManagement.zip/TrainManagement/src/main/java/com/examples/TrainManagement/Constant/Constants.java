package com.examples.TrainManagement.Constant;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.examples.TrainManagement.Model.Bogie;
import com.examples.TrainManagement.Model.Train;



public class Constants {
	public static final String FILE_PATH = "TrainsDetail.txt";
	public static final String _SPACE = " ";
	public static final String TRAIN_AB = "TRAIN_AB";
	public static final String ENGINE = "ENGINE";
	public static final String ARRIVAL = "ARRIVAL";
	public static final String DEPARTURE = "DEPARTURE";
    public static Map<String, Integer> BogieTrain; 
	public static Map<String, Integer> BogieTrainA;
    public static Map<String, Integer> BogieTrainB; 
    
    static
    {
    	BogieTrain = new HashMap<String, Integer>();
    	BogieTrain.put("CHN", 0);
        BogieTrain.put("SLM", 350);
        BogieTrain.put("BLR", 550);        
        BogieTrain.put("KRN", 900);
        BogieTrain.put("AGA", 2500);
        BogieTrain.put("NDL", 2700);  
    	BogieTrain.put("TVC", 0);
    	BogieTrain.put("SRR", 300);
    	BogieTrain.put("MAQ", 600);
    	BogieTrain.put("MAO", 1000);
    	BogieTrain.put("PNE", 1400);
    	BogieTrain.put("PTA", 3800);
    	BogieTrain.put("NJP", 4200);
    	BogieTrain.put("GHY", 4700);
    }
    
    static
    {
    	BogieTrainA = new HashMap<String, Integer>();    	
        BogieTrainA.put("HYB", 1200);
        BogieTrainA.put("NGP", 1600);
        BogieTrainA.put("ITJ", 1900);
        BogieTrainA.put("BPL", 2000);        
    }
    

    
    static
    {
    	BogieTrainB = new HashMap<String, Integer>();
    	BogieTrainB.put("HYB", 2000);
    	BogieTrainB.put("NGP", 2400);
    	BogieTrainB.put("ITJ", 2700);
    	BogieTrainB.put("BPL", 2800);    	
    }
    
    static String[] stations = {"HYB",
        	"NGP",
        	"ITJ",
        	"BPL"};
    
    static List<String> commanStation = Arrays.asList(stations);
    	
    
    
    public static Train getTrainObject(String[] dataArr, int trainNo) throws Exception {
		Train trainDetail = new Train(dataArr[0]);
		trainDetail.setTrainBogies(getBogies(dataArr, trainNo));		
		return trainDetail;
	}
    
    public static List<Bogie> getBogies(String[] dataArr, int trainNo){

    	List<Bogie> bogieList = new ArrayList<Bogie>();
		for (int i = 2; i < dataArr.length; i++) {
			String bogieStr = dataArr[i];
			if(commanStation.contains(bogieStr)) {
				if(trainNo==1) {
					bogieList.add(new Bogie(bogieStr,Constants.BogieTrainA.get(bogieStr)));
				}else {
					bogieList.add(new Bogie(bogieStr,Constants.BogieTrainB.get(bogieStr)));
				}
			}else if(Constants.BogieTrain.containsKey(bogieStr)) {
				bogieList.add(new Bogie(bogieStr,Constants.BogieTrain.get(bogieStr)));
			}
		}
		return bogieList;
	}
    
    public static boolean validateBogie(String station) {
    	if(Constants.BogieTrainB.containsKey(station) || Constants.BogieTrainA.containsKey(station)) {
    		return true;
    	}    	
    	return false;
    }
    
    public static List<String> getExternalData(String path)  {
    	try {
    		if(!path.isEmpty()) {
    			String filePath = path.contains("/")?path.replaceAll("\\\\", "/") : path;
        		File fileObj = new File(filePath);
        		if (fileObj.exists() && fileObj.length() > 10) {
        			Scanner dataReader = new Scanner(fileObj);
        			List<String> dataList = new ArrayList<String>();
        			while (dataReader.hasNextLine()) {
        				String data = dataReader.nextLine();
        				dataList.add(data);
        			}        			
        			dataReader.close();
        			return dataList;
        		}
    		}
    	}catch(FileNotFoundException fe) {
    		System.out.println("File not found");
    		fe.printStackTrace();
    		return null;
    	}
    	System.out.println("Issue while fetching the data");
		return null;		
	}
    
    public static boolean validateInput(String[] data) {
    	boolean isValid = false;
    	String[] dataArr = data;
    	if(dataArr.length > 2) {
    		isValid = true;
    	}
    	return isValid;
    }
    
    public static List<Bogie>  filteredBogie(List<Bogie> bogies, int trainNo) {
    	int hybDistance;
    	if(trainNo == 1) {
    		hybDistance = BogieTrainA.get("HYB");
    	}else {
    		hybDistance = BogieTrainB.get("HYB");
    	}    	
    	return bogies.stream().filter(b -> b.getDistance() >= hybDistance).collect(Collectors.toList());
    }
	
    public static List<Bogie>  mergedBogie(List<Bogie> bogies) {
    	List<Bogie> lst = bogies.stream().filter(b -> !b.getStation().equals("HYB")).collect(Collectors.toList());
    	return lst.stream().sorted(Comparator.comparingInt(Bogie::getDistance).reversed()).collect(Collectors.toList());
    }
	
}
