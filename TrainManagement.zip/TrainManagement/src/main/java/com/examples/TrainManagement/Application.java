package com.examples.TrainManagement;

import com.examples.TrainManagement.Constant.Constants;
import com.examples.TrainManagement.Controller.Controller;


public class Application 
{
    public static void main( String[] args)
    {
    	String fileName = args.length > 0 ? args[0] : Constants.FILE_PATH;
    	System.out.println("file Name : " + fileName);
        Controller c = new Controller();
        c.inputData(fileName);
        c.processArrivalData();
        c.outputData();
        c.clearContent();
    }
}
